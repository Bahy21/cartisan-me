enum AddressViewEnum { address, changeAddress }
