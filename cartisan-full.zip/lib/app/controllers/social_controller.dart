import 'package:get/get.dart';

class SocialController extends GetxController {}
